# Execution

Node 26 source package providing bounded shell-free process execution. Callers supply trusted, allowlisted script paths and a minimized environment; results contain only exit classification and elapsed time. Raw stdout/stderr is discarded, not audit evidence. This does not implement a sandbox, authorization, durable queue, BullMQ or MCP enforcement. The current Automation module owns its application-specific PostgreSQL audit jobs and queue state. Fixed read-only audits may be retried explicitly; arbitrary processes and external effects are not supported.
