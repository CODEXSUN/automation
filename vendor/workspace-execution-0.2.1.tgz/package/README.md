# Execution

Node 26 source package providing bounded shell-free process execution and Redis/BullMQ reference delivery. Callers supply trusted allowlisted paths, a minimized environment, durable pending references and authorization-aware business handlers. Results contain exit classification and elapsed time; raw stdout/stderr is discarded.

PostgreSQL acceptance, requester fairness, tenant binding, permissions and immutable step evidence belong to Automation. Redis carries public references only. Delivery publishes at most100 references in one bounded batch per two-second reconciliation cycle, with stable IDs and one worker slot. Producer commands have a two-second deadline and one request retry. Redis reconnect backoff caps at four seconds for the service lifetime; it is distinct from business execution, which has one start attempt and no automatic stalled re-execution. Shutdown drains the owner handler under the owner supervisor's deadline.

Reconciliation records unavailable health on PostgreSQL or Redis failure, keeps the database as the recovery source and resumes the next cycle after recovery. This package does not grant authority, migrate/seed databases, provide a sandbox or enforce MCP governance. Arbitrary processes and external effects remain unsupported by Automation's fixed read-only audit handler.
